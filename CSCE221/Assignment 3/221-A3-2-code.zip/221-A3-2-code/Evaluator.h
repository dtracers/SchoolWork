#ifndef EVALUATOR_H
#define EVALUATOR_H

#include "Parser.h"
//#include "LinkedList.h"
//#include "LinkedStack.h"
#include "RuntimeException.h"

class Evaluator {
public:
  // user-defined exceptions
  class DivisionByZeroException : public RuntimeException {
    public:
      DivisionByZeroException() : RuntimeException("Division by zero") {}
  };     
private:
  map<string,Parser*> * operations;
	/* declare member variables;
	may include a string postfix queue and a double value stack */
	LinkedStack<Element>* list;
	/* declare utility functions */
	double getValue(Element num1,Element num2,Element op);
public:
	  Evaluator(Parser* par,map<string,Parser*>* op) {list=par->getList();operations=op;}
	  Evaluator(LinkedStack<Element>* par,map<string,Parser*>* op) {list=par;operations=op;}// constructor
	double getValue(); // returns the result of expression evaluation

};

#endif
