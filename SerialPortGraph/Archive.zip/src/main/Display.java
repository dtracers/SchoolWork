package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Display extends JPanel
{
	public JComboBox listOfPorts;
	public JButton initialize;
	public JButton start;
	public JButton stop;
	public JButton close;
	public JPanel paintPanel;
	
	boolean initializeEnabled;
	boolean running;
	
	public void makePanel()
	{
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridy=0;
		paintPanel=getPaintPanel();
		add(paintPanel,gbc);
		
		
		JPanel button=getButtonPanel();
		gbc = new GridBagConstraints();
		gbc.gridy=1;
		add(button,gbc);
		
		
	}
	public JPanel getButtonPanel()
	{
		//creates panel
		JPanel p=new JPanel();
		p.setOpaque(false);
		p.setLayout(new GridBagLayout());
		p.setPreferredSize(new Dimension(800,40));
		//sets up constants
		int x_value=0;
		GridBagConstraints gridBag;
		
		//Jlabel
		JLabel label=new JLabel("List of Ports:");
		gridBag = new GridBagConstraints();
		gridBag.gridx = ++x_value;
		p.add(label,gridBag);
		
		//listport
		listOfPorts=new JComboBox(Input.getPortNames());
		listOfPorts.addItemListener(new ItemListener()
		{

			@Override
			public void itemStateChanged(ItemEvent arg0)
			{
				Runner.input.setPortName(""+arg0.getItem());
				initializeEnabled=true;
				if(initialize!=null)
					initialize.setEnabled(true);
			}
		
		});
		gridBag = new GridBagConstraints();
		gridBag.gridx = ++x_value;
		p.add(listOfPorts,gridBag);
		
		//Initialize
		initialize=new JButton("Initialize Serial Port");
		initialize.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				Runner.input.currentPortName=""+listOfPorts.getSelectedItem();
				Runner.input.initialize();
				if(close!=null)
					close.setEnabled(true);
				initialize.setEnabled(false);
				initializeEnabled=false;
			}
			
		});
		gridBag = new GridBagConstraints();
		gridBag.gridx = ++x_value;
		p.add(initialize,gridBag);
		
		//Start
		start=new JButton("Start Reading");
		start.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				Runner.input.startReading();
				start.setEnabled(false);
				if(stop!=null)
					stop.setEnabled(true);
				running=true;
			}
			
		});
		gridBag = new GridBagConstraints();
		gridBag.gridx = ++x_value;
		p.add(start,gridBag);
		
		//stop
		stop=new JButton("Stop Reading");
		stop.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				Runner.input.stopReading();
				stop.setEnabled(false);
				if(start!=null)
					start.setEnabled(true);
				running=true;
			}
			
		});
		gridBag = new GridBagConstraints();
		gridBag.gridx = ++x_value;
		p.add(stop,gridBag);
		
		//stop
		close=new JButton("Close port");
		close.setEnabled(false);
		close.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				Runner.input.close();
				close.setEnabled(false);
				if(initialize!=null)
					initialize.setEnabled(true);
			}
			
		});
		gridBag = new GridBagConstraints();
		gridBag.gridx = ++x_value;
		p.add(close,gridBag);
		
		
		return p;
	}

	public JPanel getPaintPanel()
	{
		JPanel panel=new JPanel()
		{
			public void paint(Graphics g)
			{
				g.setColor(Color.white);
				g.fillRect(0, 0, getWidth(), getHeight());
				g.setColor(Color.black);
				g.drawRect(0, 0, getWidth()-1, getHeight()-1);
			}
		};
		panel.setOpaque(true);
		panel.setPreferredSize(new Dimension(600,500));
		return panel;
	}
}
