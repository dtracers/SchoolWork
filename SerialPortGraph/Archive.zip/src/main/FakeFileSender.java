package main;

import java.util.Scanner;

import jssc.SerialPort;
import jssc.SerialPortException;

public class FakeFileSender
{
	public static void run()
	{
		System.out.println("Running other file");
		SerialPort serialPort = new SerialPort("/dev/slave");
		System.out.println("finished making serial port");
		try
		{
			System.out.println("Opening port");
		    serialPort.openPort();//Open serial port
		    System.out.println("post open");
		    serialPort.setParams(9600, 8, 1, 0);//Set params.
		}catch(SerialPortException ex)
		{
			ex.printStackTrace();
		}
		Scanner s=new Scanner(System.in);
		String str="";
		do
		{
			str=s.nextLine();
			try
			{
				serialPort.writeString(str);
			}catch(SerialPortException ex)
			{
				ex.printStackTrace();
			}
		}
		while(str!=null&&!str.equals("")&&!str.equals("done"));
		try
		{
			if(serialPort.closePort())
				System.out.println("Closed nicely");
			else
				System.out.println("I did not close");
		} catch (SerialPortException e)
		{
			e.printStackTrace();
		}
		System.out.println("Program ended");
	}
}
