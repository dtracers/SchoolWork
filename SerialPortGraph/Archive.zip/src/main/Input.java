package main;

import java.util.Queue;

import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;


/**
 * This sets up to and receives input from the serial port.
 * It will continually set up snapShots which will then add to an array with a thread.
 * Then there will be a queue that will read from the array.
 * This extra step provides a secondary buffer to the first buffer
 * This Queue will then be read at certain times so that the data is then saved correctly
 * initialize
 * @author gigemjt
 *
 */
public class Input
{
	public static final int SERIAL_PORT=1;
	snapShot[] buffer1;
	Queue<snapShot> buffer2;
	static String[] portNames = SerialPortList.getPortNames();
	String currentPortName;
	SerialPort serialPort;
	
	public void initialize()
	{
	//	currentPortName="/dev/master";
		System.out.println("Current port name is "+currentPortName);
		serialPort = new SerialPort(currentPortName);
		try
		{
			System.out.println("Opening port");
		    serialPort.openPort();//Open serial port
		    System.out.println("port open");
		    serialPort.setParams(9600, 8, 1, 0);//Set params.
		}catch(SerialPortException ex)
		{
			ex.printStackTrace();
		}
	}
	public void startReading()
	{
		//this is how you read a serial port
		Thread d=new Thread()
		{
			public void run()
			{
	            try
				{
	            	System.out.println("Ready to read");
					String buffer = serialPort.readString();
					if(buffer==null)
					{
						System.out.println("buffer is empty");
					}else
					{
						System.out.println(buffer);
					}
				} catch (SerialPortException e)
				{
					e.printStackTrace();
				}//Read 10 bytes from serial port
			}
		};
		d.start();
	}
	public void stopReading()
	{

	//	serialPort.closePort();//Close serial port
	}
	public void setPortName(String st)
	{
		currentPortName=st;
	}
	public static String[] getPortNames()
	{
		if(portNames.length==0)
			return new String[]{"/dev/master"};
		
		int off=2;
		String[] ret=new String[portNames.length+off];
		for(int k=off;k<ret.length;k++)
		{
			ret[k]=portNames[k-off];
		}
		ret[0]="/dev/master";
		ret[1]="/dev/slave";
		return ret;
	}
	public void close()
	{
		System.out.println("trying to close port");
		boolean closed=false;
		try
		{
			closed=serialPort.closePort();
		} catch (SerialPortException e)
		{
			e.printStackTrace();
		}
		if(closed)
		System.out.println("port closed successfully");
		else
			System.out.println("port closing failed");
	}
}
/**
 * This just contains the snapShot of the serial port so that it will set up the graph correctly
 * @author gigemjt
 *
 */
class snapShot
{
	
}

